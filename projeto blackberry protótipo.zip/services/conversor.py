# implementa a lógica de conversão. decide se o arquivo será copiado ou re-encodificado, com auxílio do ffprobe e os metadados

from services.formatos import carregar_formatos

formatos = carregar_formatos()