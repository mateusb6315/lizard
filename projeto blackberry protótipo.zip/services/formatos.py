# recupera os metadados dos formatos e fornece para conversor.py

import json
from pathlib import Path

METADADOS = Path(__file__).parent.parent / "data" / "formatos"

def carregar_formatos():
    formatos = {}